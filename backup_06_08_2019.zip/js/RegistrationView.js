//TODO Make Validation
class RegistrationView{
    constructor(registrationFormID){
        this._registrationForm = document.querySelector(registrationFormID);

        this._name = null;
        this._email = null;
        this._phone = null;
        this._address = null;
        this._city = null; 
        this._state = null;

        this._errors = [];
    
    }

    
    getData(){
        this._name = this._registrationForm.querySelector("input[name=name]").value;
        this._email = this._registrationForm.querySelector("input[name=email]").value;
        this._phone = this._registrationForm.querySelector("input[name=phone]").value;
        this._address = this._registrationForm.querySelector("input[name=address]").value;
        this._city = this._registrationForm.querySelector("input[name=city]").value;
        this._state = this._registrationForm.querySelector("input[name=state]").value;
    }
    async validateForm(){
        let errors = [];
        if(!Validator.validateEmail(this._email)) errors.push("Eamil is incorect");
        if(!Validator.validateString(this._name)) errors.push("Name is incorect");
        if(!Validator.validatePhoneNumber(this._phone)) errors.push("Phone number is incorect");
        if(!Validator.isFiled(this._address)) errors.push("Address is empty");
        if(!Validator.isFiled(this._city)) errors.push("City is empty");
        if(!Validator.isFiled(this._state)) errors.push("State is empty");
        if(!await Validator.checkUniqueEmail(this._email)) errors.push("User with this email already exist");
        if(!await Validator.checkUniquePhone(this._phone)) errors.push("User with this phone already exist");
        errors
        console.dir(errors);
        this._errors = errors;
        return errors.length == 0;
    }
    clearInputs(){
        this._registrationForm.querySelector("input[name=name]").value = "";
        this._registrationForm.querySelector("input[name=email]").value = "";
        this._registrationForm.querySelector("input[name=phone]").value = "";
        this._registrationForm.querySelector("input[name=address]").value = "";
        this._registrationForm.querySelector("input[name=city]").value = "";
        this._registrationForm.querySelector("input[name=state]").value = "";
    }
    getUserInfoObject(){
        return {
            name: this._name,
            email: this._email,
            phone: this._phone,
            address: this._address,
            city: this._city,
            state: this._state,
        };
    }
    createUser(){
        Messanger.sendMessage("setUserInfo", this.getUserInfoObject());
    }

}